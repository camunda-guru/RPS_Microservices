package com.wellsfargo.travel.CustomerService;

import org.junit.Test;
import org.junit.runner.RunWith;


//@RunWith(SpringRunner.class)
//@SpringBootTest
public class CustomerServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
