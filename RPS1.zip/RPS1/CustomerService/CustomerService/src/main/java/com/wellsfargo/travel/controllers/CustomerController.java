package com.wellsfargo.travel.controllers;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.travel.model.Customer;
import com.wellsfargo.travel.repositories.CustomerRepository;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerRepository customerRepository;
	
	@RequestMapping(method = RequestMethod.POST)
    public Customer create(@RequestBody Customer customer){
         customer.set_id(new ObjectId());
         System.out.println(customer.getFirstName());
        Customer result = customerRepository.save(customer);
        return result;
    }
     
    @RequestMapping(method = RequestMethod.GET, value="/search/{email}")
    public Customer get(@PathVariable String email){
        return customerRepository.findOne(email);
    }
}
