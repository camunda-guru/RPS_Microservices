package com.wellsfargo.travel.repositories;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.travel.model.Customer;
@Transactional
public interface CustomerRepository extends MongoRepository<Customer, String>{

}
